package GUI;

import Clases.Ruta;
import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.util.ArrayList;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.table.DefaultTableModel;


public class BuscadorDeRutas {
    public BuscadorDeRutas() {
        JFrame ventana = new JFrame("Buscador de rutas");
        ventana.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        ventana.setSize(600, 400);
        ventana.setLayout(new BorderLayout(10, 10));
        
        JPanel panelDeEntrada = new JPanel(new GridLayout(5, 2, 10, 10));
        panelDeEntrada.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        
        JLabel origenLabel = new JLabel("Municipio de origen:");
        JComboBox<String> origenComboBox = new JComboBox<>(new String[]{"Bogotá", "Medellín"});
        origenComboBox.setSelectedItem("Bogotá");
        
        JLabel destinoLabel = new JLabel("Municipio de destino:");
        JComboBox<String> destinoComboBox = new JComboBox<>(new String[]{"Bogotá", "Medellín"});
        destinoComboBox.setSelectedItem("Medellín");
        
        JButton botonBuscar = new JButton("Buscar rutas:");
        
        String[] nombreColumnas = {"Empresa", "Origen", "Destino", "Precio (COP)", "Tiempo Estimado"};
        DefaultTableModel modeloTabla = new DefaultTableModel(nombreColumnas, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        
        JTable tabla = new JTable(modeloTabla);
        JScrollPane tablaScroll = new JScrollPane(tabla);
        
        List<Ruta> todasLasRutas = EjemplosDeRutas();
        botonBuscar.addActionListener(e -> {
            String origen = (String) origenComboBox.getSelectedItem();
            String destino = (String) destinoComboBox.getSelectedItem();
            
            modeloTabla.setRowCount(0);
            
            for (Ruta ruta : todasLasRutas) {
                if (ruta.getOrigen().equals(origen) && ruta.getDestino().equals(destino)) {
                    String duracionConFormato = String.format("%d h %d min",
                            ruta.getDuracion() / 60, ruta.getDuracion() % 60);
                    modeloTabla.addRow(new Object[]{
                        ruta.getCompañia(),
                        ruta.getOrigen(),
                        ruta.getDestino(),
                        String.format("%,.0f", ruta.getPrecio()),
                        duracionConFormato
                    });
                }
            }
            
            if (modeloTabla.getRowCount() == 0)
                JOptionPane.showMessageDialog(ventana,
                        "No se encontraron rutas.",
                        "Sin resultados",
                        JOptionPane.INFORMATION_MESSAGE);
        });
        
        panelDeEntrada.add(origenLabel);
        panelDeEntrada.add(origenComboBox);
        panelDeEntrada.add(destinoLabel);
        panelDeEntrada.add(destinoComboBox);
        panelDeEntrada.add(new JLabel());
        panelDeEntrada.add(botonBuscar);
        
        tabla.getColumnModel().getColumn(0).setPreferredWidth(150);
        tabla.getColumnModel().getColumn(1).setPreferredWidth(100);
        tabla.getColumnModel().getColumn(2).setPreferredWidth(100);
        tabla.getColumnModel().getColumn(3).setPreferredWidth(100);
        tabla.getColumnModel().getColumn(4).setPreferredWidth(120);
        
        ventana.add(panelDeEntrada, BorderLayout.NORTH);
        ventana.add(tablaScroll, BorderLayout.CENTER);
        ventana.setVisible(true);
    }
    
    
    private List<Ruta> EjemplosDeRutas() {
        List<Ruta> rutas = new ArrayList<>();
        
        rutas.add(new Ruta("Expreso Bolivariano", "Bogotá", "Medellín", 65000.0, 540));
        rutas.add(new Ruta("Flota Occidental", "Bogotá", "Medellín", 70000.0, 510));
        rutas.add(new Ruta("Copetran", "Bogotá", "Medellín", 68000.0, 525));
        rutas.add(new Ruta("Expreso Brasilia", "Bogotá", "Medellín", 72000.0, 500));
        
        return rutas;
    }
    
    public static void main(String[] args) {
        BuscadorDeRutas gui = new BuscadorDeRutas();
    }
}
